"use strict;"

const calculadora = require('./calculadora.js');

console.log(calculadora.suma(3, 8));
