"use strict;"

console.log('Iniciando al calculadora...');

function suma(a, b) {
    return a + b;
}

function resta(a, b) {
    return a - b;
}


module.exports = {
    suma: suma,
    resta: resta
}
